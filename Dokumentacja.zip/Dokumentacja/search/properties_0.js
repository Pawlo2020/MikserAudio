var searchData=
[
  ['bordercolor_46',['BorderColor',['../class_audio_display_1_1_display.html#a4d2ff5b306fbda1a0a54dcd8626cefcd',1,'AudioDisplay::Display']]]
];
