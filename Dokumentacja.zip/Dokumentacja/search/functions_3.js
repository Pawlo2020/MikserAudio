var searchData=
[
  ['setbackground_38',['SetBackground',['../class_audio_display_1_1_vertical_bar.html#aab9c611ef68ba54236484b08d8e8d1ff',1,'AudioDisplay::VerticalBar']]],
  ['setbackgroundcolor_39',['SetBackgroundColor',['../class_audio_display_1_1_display.html#ac209d686b4cfcdad912ee0f86e8146f2',1,'AudioDisplay::Display']]],
  ['setbarcolor_40',['SetBarColor',['../class_audio_display_1_1_display.html#aa8e88cd18fa94870d6161c958278e5d8',1,'AudioDisplay::Display']]],
  ['setbordercolor_41',['SetBorderColor',['../class_audio_display_1_1_display.html#a136f2893ee431818f5578a630b0165f4',1,'AudioDisplay::Display']]],
  ['setvalue_42',['SetValue',['../class_audio_display_1_1_vertical_bar.html#aa3410caa36933f33a13089b34610898a',1,'AudioDisplay::VerticalBar']]]
];
