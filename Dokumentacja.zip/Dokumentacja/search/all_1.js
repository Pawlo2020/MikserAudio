var searchData=
[
  ['barmodel_1',['BarModel',['../struct_audio_display_1_1_display_1_1_bar_model.html',1,'AudioDisplay::Display']]],
  ['bordercolor_2',['BorderColor',['../class_audio_display_1_1_display.html#a4d2ff5b306fbda1a0a54dcd8626cefcd',1,'AudioDisplay::Display']]]
];
