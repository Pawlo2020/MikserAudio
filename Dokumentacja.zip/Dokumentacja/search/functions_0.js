var searchData=
[
  ['display_27',['Display',['../class_audio_display_1_1_display.html#a6fd5af114eaaf35383f1c6d29d8093cb',1,'AudioDisplay::Display']]],
  ['dispose_28',['Dispose',['../class_audio_display_1_1_display.html#a3ed74c3f8c80e045cdae24559c8c84dd',1,'AudioDisplay.Display.Dispose()'],['../class_audio_display_1_1_vertical_bar.html#a81b3408a6ad196125a5be828ed12b3c2',1,'AudioDisplay.VerticalBar.Dispose()']]]
];
